MUHAMMAD ILYAS FAKHRI PRASETYO

TO_DO APP

Aplikasi ini digunakan untuk menajemen tugas yang membantu pengguna mencatat, dan mengatur tugas atau kegiatan yang harus dilakukan


1. Menambah Tugas
   - Judul tugas
   - Jam
   - Waktu
2. Melihat Daftar tugas
   - Tenggat waktu
   - Status
   - Edit
   - Hapus
3. Menandai Tugas Selesai
   Pengguna dapat mencentang tugas yang telah diselesaikan agar di centang sebagai selesai
4. Mengedit dan Menghapus tugas
   Edit Memungkinkan pengguna memperbarui detail tugas
   Hapus : Menghapus tugas yang tidak diperlukan

Teknologi yang di gunakan dalam project ini
Firebase
Google Cloud
Flutter


1. Buka website
2. Sign Up jika belum ada akun
3. Sign In jika sudah ada akun
4. Klik tanda + untuk menambahkan tugas
5. Isi Task, Waktu, dan Hari
6. Klik Tambahkan
7. Klik Sidebar
8. Akan ada Task, Lihat Kalender, dan Log out
9. klik lihat kalender untuk lihat tenggat

Sign in
![image](https://github.com/user-attachments/assets/ff07fba3-d2ac-4706-add6-1d38b66bcb43)
Sign Up
![image](https://github.com/user-attachments/assets/c80f986b-5cf8-4c05-bbd2-f27c62782db5)
Task-list homepage
![image](https://github.com/user-attachments/assets/7fe8d59d-9e82-4a42-a45e-4a05e37c62c1)
Add Task
![image](https://github.com/user-attachments/assets/b204fad0-4f97-4985-9c41-c433d923f366)

Calender
![image](https://github.com/user-attachments/assets/e7b338cd-1dd8-4c82-befb-b3cdff1d9f5d)
Profile
![image](https://github.com/user-attachments/assets/df02ff23-efd3-4fa0-823d-a322d2446c10)




